import os
import json
import numpy as np
from PIL import Image, ImageOps
from keras.models import model_from_json
from keras.preprocessing import image
from tensorflow.compat.v1 import gfile


class MNISTClassifier(object):
  def __init__(self, model):
    self._model = model
  
  @classmethod
  def from_path(cls, model_dir):
    model = None
    model_json_file = os.path.join(model_dir, 'model.json')
    model_weight_file = os.path.join(model_dir, "model.h5")
    
    with open(model_json_file, 'r') as jsonfile:
      loaded_model_json = jsonfile.read()
    
    model = model_from_json(loaded_model_json)
    model.load_weights(model_weight_file)

    return cls(model)

  def _preprocess_image(self, imgfile):
    with gfile.Open(imgfile, 'rb') as imgfileobj:
      img = Image.open(imgfileobj).convert("L") #image.load_img(path=imgfileobj, color_mode="grayscale", target_size=(28, 28, 1,))
      img = img.resize((28, 28), Image.ANTIALIAS)
      img = ImageOps.invert(img)
      img = image.img_to_array(img)
      img = np.expand_dims(img, axis=0)

    return img

  def _transform_result(self, result):
    result = [ { str(k): v } for k, v in enumerate(result)]
    sort_by_dict_value = lambda x: list(x.values())[0]

    result = sorted(result, key=sort_by_dict_value, reverse=True)

    return result

  def predict(self, instances, **kwargs):
    result = []

    for imgfile in instances:
      img = self._preprocess_image(imgfile)
      res = self._model.predict(img).flatten().tolist()
      res = self._transform_result(res)

      result.append({
        "file": imgfile,
        "result": res
      })

    return result


# if __name__ == "__main__":
#   IMAGE_DIR = './images'
#   clf = MNISTClassifier.from_path("./model")
#   imgFiles = [f"{IMAGE_DIR}/{i}" for i in os.listdir(IMAGE_DIR) if ".png" in i or ".jpg" in i]

#   p = clf.predict(imgFiles)
#   print(p)