from setuptools import setup

REQUIRED_PACKAGES = ['keras', 'pillow<7']

setup(
    name="mnist_classifier",
    version="0.1",
    packages=[],
    scripts=["model.py"],
    install_requires=REQUIRED_PACKAGES
)